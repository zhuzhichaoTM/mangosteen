# Mangosteen 大模型部署助手 Skill

这是一个 WorkBuddy 技能，用于封装 Mangosteen 大模型部署客户端的核心功能。

## 功能特性

- ✅ 本地优先的模型部署策略
- ✅ 自动资源评估（显存/内存）
- ✅ 云端算力弹性补位
- ✅ OpenAI 兼容接口
- ✅ 跨平台支持（macOS/Windows/Linux）
- ✅ 智能云端选点（四维打分）
- ✅ 模型管理（下载/搜索/验证）
- ✅ 完整生命周期管理

## 安装

此 skill 已安装在用户级技能目录：
```
~/.workbuddy/skills/mangosteen-llm-deployer/
```

## 使用示例

### 部署模型

```
部署 qwen2.5-7b 模型，上下文 8192
```

### 评估资源

```
评估 llama3.3-70b 能不能在本地跑
```

### 云端选型

```
找一个 24GB 显存的最便宜的云端实例
```

### 模型管理

```
下载 Qwen2.5-7B 模型
```

### 生命周期管理

```
停止所有部署
```

## 前置条件

使用此 skill 前需要先安装 Mangosteen：

### macOS

```bash
# 使用 Homebrew
brew install mangosteen

# 或从 Release 下载
# macOS (Intel): mangosteen-macos-x86_64.tar.gz
# macOS (Apple Silicon): mangosteen-macos-aarch64.tar.gz
```

### Linux

```bash
# 从 Release 下载
# Linux (x86_64): mangosteen-linux-x86_64.tar.gz
# Linux (aarch64): mangosteen-linux-aarch64.tar.gz
```

### Windows

```bash
# 从 Release 下载
# Windows (x86_64): mangosteen-windows-x86_64.zip
```

## 目录结构

```
mangosteen-llm-deployer/
├── SKILL.md                    # 核心定义文件
├── references/                 # 参考文档
│   ├── commands.md           # 命令速查表
│   ├── resource-estimation.md # 资源评估公式
│   ├── cloud-providers.md    # 云服务商配置指南
│   └── troubleshooting.md    # 故障排查手册
├── scripts/                   # 辅助脚本
│   ├── detect-platform.sh     # 平台检测
│   └── health-check.sh        # 环境健康检查
└── README.md                  # 本文件
```

## 核心概念

### 本地优先策略

调度决策器严格按此顺序：
```
本地资源满足 → 本地部署（永远优先）
本地资源不足 → 云端降级（只在必要时）
本地部署失败 → 云端降级 + 记录原因
```

### 资源评估公式

```
总需求 = 权重 + KV Cache + 计算缓冲 + 运行时开销
```

### 云端四维打分

```
总分 = w_price·价格分 + w_latency·延迟分 + w_availability·可用性分 + w_hardware·硬件分
```

## 辅助脚本

### 平台检测

```bash
bash ~/.workbuddy/skills/mangosteen-llm-deployer/scripts/detect-platform.sh
```

输出当前操作系统和架构，推荐对应的下载文件。

### 环境健康检查

```bash
bash ~/.workbuddy/skills/mangosteen-llm-deployer/scripts/health-check.sh
```

检查 Mangosteen 运行环境是否正常。

## 安全提醒

⚠️ **云端计费警告**：
- 云端实例按小时计费，用完必须销毁
- 台账会记录所有实例，建议定期检查 `mangosteen cloud instances`
- 压测规则：同一时刻只允许 1 台 GPU 实例运行

⚠️ **凭证安全**：
- 云服务商凭证支持环境变量、文件、内联三种方式
- `config show` 不会明文输出凭证

## 参考文档

详细文档请查看 `references/` 目录：
- commands.md - 命令速查表
- resource-estimation.md - 资源评估公式详解
- cloud-providers.md - 云服务商配置指南
- troubleshooting.md - 故障排查手册

## 相关链接

- Mangosteen 仓库: https://github.com/zhuzhichaoTM/mangosteen
- Mangosteen 文档: 见项目 README.md

## 版本信息

- Skill 版本: 1.0.0
- 作者: 朱志超
- 许可: Apache-2.0
