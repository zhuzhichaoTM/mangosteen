## Description: <br>
个人级大模型部署客户端：本地算力优先+云端弹性补位。自动评估显存/内存需求，本地不足时自动上云，提供 OpenAI 兼容接口。支持 macOS/Windows/Linux 三个平台，适合开发者、研究者快速部署大模型推理服务。 <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[朱志超](https://github.com/zhuzhichaoTM) <br>

### License/Terms of Use: <br>
Apache-2.0 <br>

## Use Case: <br>
Developers and researchers use this skill to deploy large language models with local-first compute and cloud elasticity. It automatically evaluates VRAM/memory needs, falls back to cloud when local resources insufficient, and provides OpenAI-compatible API. Suitable for quick deployment of LLM inference services on macOS/Windows/Linux. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Cloud instances incur hourly charges; forgetting to stop instances may lead to unexpected costs. <br>
Mitigation: The skill provides explicit cost warnings and automated ledger tracking. Users should monitor deployment status with `mangosteen cloud instances` and stop unused instances with `mangosteen stop --all`. <br>

Risk: Cloud provider credentials may be exposed if misconfigured. <br>
Mitigation: Credentials support environment variables and file-based storage. The skill never displays credentials in plaintext. Users should follow credential security best practices. <br>

Risk: CPU inference on local machines may be slow (<5 tok/s). <br>
Mitigation: The skill provides resource assessment before deployment. Users can choose to deploy to cloud for GPU acceleration when local resources are insufficient. <br>

## Reference(s): <br>
- [Mangosteen GitHub Repository](https://github.com/zhuzhichaoTM/mangosteen) <br>
- [Mangosteen Documentation](https://github.com/zhuzhichaoTM/mangosteen/blob/main/README.md) <br>

## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Configuration] <br>
**Output Format:** [Command outputs, deployment status, configuration files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs include deployment status, resource assessment results, and configuration recommendations for human review before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified configuration files before applying them, and apply their organization's security, compliance, and cost management requirements before deploying to cloud providers. Cloud deployment may incur costs; users should monitor usage and costs. <br>
