---
name: mangosteen-llm-deployer
display_name: 大模型部署助手
display_name_en: LLM Deployment Assistant
description: 当用户需要部署本地大模型、评估模型资源需求、使用云端算力弹性部署、或需要 OpenAI 兼容推理接口时使用此技能。支持本地优先策略，自动处理模型下载、资源评估、部署编排和生命周期管理。
description_zh: 个人级大模型部署客户端，本地算力优先+云端弹性补位。自动评估显存/内存需求，本地不足时自动上云，提供 OpenAI 兼容接口。
description_en: Personal LLM deployment client with local-first compute and cloud elasticity. Automatically evaluates VRAM/memory needs, falls back to cloud when local resources insufficient, provides OpenAI-compatible API.
examples_zh:
  - "部署 qwen2.5-7b 模型，上下文 8192"
  - "评估 llama3.3-70b 能不能在本地跑"
  - "找一个 24GB 显存的最便宜的云端实例"
  - "启动模型推理服务"
  - "停止所有部署"
examples_en:
  - "Deploy qwen2.5-7b model with 8192 context"
  - "Assess if llama3.3-70b can run locally"
  - "Find the cheapest cloud instance with 24GB VRAM"
  - "Start model inference service"
  - "Stop all deployments"
version: 1.0.0
author: "朱志超"
tags: [llm, deployment, local-inference, cloud-compute, ai-infra]
allowed-tools: Bash, Read, Write, Edit
trigger_keywords: [部署模型, 大模型推理, 本地推理, 云端算力, 模型下载, 评估资源, mangosteen]
---

# Mangosteen 大模型部署助手

## 角色定位

你是大模型部署专家，使用 Mangosteen 工具为用户提供本地优先、云端弹性的模型部署服务。核心原则：**本地优先，云端补位**。

## 前置条件

### 安装 Mangosteen

#### 方式 1：从 Release 下载（推荐）

1. 访问 https://github.com/zhuzhichaoTM/mangosteen/releases
2. 下载对应平台的发布包：
   - macOS (Intel): `mangosteen-macos-x86_64.tar.gz`
   - macOS (Apple Silicon): `mangosteen-macos-aarch64.tar.gz`
   - Linux (x86_64): `mangosteen-linux-x86_64.tar.gz`
   - Linux (aarch64): `mangosteen-linux-aarch64.tar.gz`
   - Windows (x86_64): `mangosteen-windows-x86_64.zip`
3. 解压到 PATH 目录
4. 验证安装：`mangosteen --version`

#### 方式 2：从源码编译

```bash
git clone https://github.com/zhuzhichaoTM/mangosteen.git
cd mangosteen
cargo build --release
export PATH="$PWD/target/release:$PATH"
```

#### 方式 3：使用辅助脚本检测平台

```bash
bash ~/.workbuddy/skills/mangosteen-llm-deployer/scripts/detect-platform.sh
```

该脚本会自动检测当前平台并推荐对应的下载文件。

#### 方式 4：一键环境准备

```bash
bash ~/.workbuddy/skills/mangosteen-llm-deployer/scripts/prepare-env.sh
```

该脚本会检查 mangosteen 安装状态、配置文件和本地模型。

### 环境检查

在执行任何部署操作前，必须先检查环境：

```bash
# 1. 检查 mangosteen 是否安装
mangosteen --version

# 2. 运行环境自检
mangosteen doctor

# 3. 查看当前配置
mangosteen config show
```

如果 mangosteen 未安装，按照上述安装步骤进行安装。
- Windows: 从 Release 下载 zip 并解压到 PATH

## 核心工作流

### 场景 1：部署模型（最常用）

**用户意图**：部署某个模型进行推理

**执行步骤**：

1. **资源评估（可选但推荐）**
   ```bash
   # 先评估，不部署
   mangosteen assess <模型名> --context <上下文长度>
   ```
   - 输出会显示：权重大小、KV Cache 需求、总显存需求、本地是否足够
   - 如果本地不足，会提示需要多大云端显存

2. **部署决策**
   - 如果本地足够：直接本地部署
   - 如果本地不足：询问用户是否接受云端部署（会提示预估费用）

3. **执行部署**
   ```bash
   # 本地部署
   mangosteen deploy <模型名> --context <上下文长度>

   # 强制本地（绝不花钱）
   mangosteen deploy <模型名> --local-only

   # 云端部署（显示规格和价格）
   mangosteen deploy <模型名> --context <上下文长度>
   # 系统会弹窗列出候选规格、资源需求、预估时价，用户确认后才创建
   ```

4. **验证部署**
   ```bash
   # 查看活跃部署
   mangosteen status

   # 查看 OpenAI 入口
   # 默认：http://127.0.0.1:11516/v1
   ```

**输出格式**：
```
✓ 部署完成：<模型名> (本地算力/云端算力)
  落位形态   全部层驻显存 / 部分卸载
  上下文     <上下文长度>
  资源占用   权重 X GiB + KV Y GiB + 计算缓冲 Z GiB = 总计 T GiB
  OpenAI 入口 http://127.0.0.1:11516/v1
```

### 场景 2：云端算力选型

**用户意图**：寻找合适的云端 GPU 实例

**执行步骤**：

1. **查看可用规格**
   ```bash
   # 列出所有服务商和规格
   mangosteen cloud providers
   mangosteen cloud specs
   ```

2. **智能选点（带打分依据）**
   ```bash
   # 按最低显存和价格上限筛选，显示打分依据
   mangosteen cloud pick --min-vram <显存GB> --max-price <元/小时> --explain
   ```
   - 输出示例：
     ```
     ★ autodl/RTX 4090 [cn-west-1] ¥2.380/h · 42ms · 24.0GiB
       价格 1.00 延迟 1.00 可用 0.92 硬件 0.94 → 总分 0.9654
     ```

3. **最便宜优先（不考虑打分）**
   ```bash
   mangosteen cloud cheapest --min-vram <显存GB>
   ```

4. **创建实例（可选）**
   ```bash
   # 一步到位：选最便宜的并创建
   mangosteen cloud cheapest --min-vram <显存GB> --create --yes --name <实例名>

   # 用完销毁
   mangosteen cloud destroy --instance <实例ID> --yes
   ```

**重要提醒**：
- 云端实例按小时计费，用完必须销毁
- 台账会记录所有实例，可用 `mangosteen cloud instances` 查看
- `mangosteen stop --all` 会停止所有部署（包括云端）

### 场景 3：模型管理

**用户意图**：下载、搜索、管理本地模型

**执行步骤**：

1. **搜索模型**
   ```bash
   # 查看仓库里的 GGUF 文件
   mangosteen models search <仓库ID>
   # 例如：mangosteen models search Qwen/Qwen2.5-0.5B-Instruct-GGUF
   ```

2. **下载模型**
   ```bash
   # 下载（默认 modelscope，国内快）
   mangosteen models pull <完整模型路径>

   # 指定源
   mangosteen models pull hf:<完整模型路径>
   ```

3. **查看本地模型**
   ```bash
   mangosteen models list
   ```

4. **添加已有模型**
   ```bash
   mangosteen models add <本地路径>
   ```

**下载机制**：
- 自动断点续传
- 边下边算 SHA-256 校验
- 临时文件 `.part`，校验通过才改名（原子操作）
- 重复执行直接命中缓存

### 场景 4：生命周期管理

**用户意图**：停止、恢复、删除部署

**执行步骤**：

1. **查看所有部署**
   ```bash
   mangosteen ps  # 列出全部部署记录
   ```

2. **停止部署**
   ```bash
   # 停止指定部署
   mangosteen stop <部署ID>

   # 停止所有
   mangosteen stop --all --yes
   ```

3. **删除部署**
   ```bash
   # 卸载（云端会销毁实例）
   mangosteen delete <部署ID>
   ```

**云端生命周期注意事项**：
- stop_service：停进程 → 关机 → 关隧道（实例保留）
- delete：销毁实例（回收资源）
- 台账每次状态变更立即落盘，避免忘记关机导致持续扣费

### 场景 5：环境自检与故障排查

**用户意图**：检查环境是否正常

**执行步骤**：

```bash
# 完整自检
mangosteen doctor
```

**常见问题处理**：

1. **引擎动态库找不到**
   ```bash
   # 查看注入的库路径
   mangosteen engine env

   # 查看搜索过的目录
   mangosteen engine locate

   # 手动指定（在 config.toml 中）
   [local.engine_env]
   DYLD_FALLBACK_LIBRARY_PATH = "/opt/my-llama/lib"  # macOS/Linux
   ```

2. **端口被占用**
   ```bash
   mangosteen stop --all
   # 或修改配置 port_range_start/port_range_end
   ```

3. **云端实例忘了关**
   ```bash
   mangosteen cloud instances
   mangosteen stop <部署ID>
   ```

## 配置文件模板

### 最小配置（纯本地 CPU 推理）

```toml
config_version = 1

[gateway]
port = 11516
host = "127.0.0.1"
require_api_key = false

[scheduler]
local_first = true
strategy = "cheapest"
max_fallbacks = 2

[local]
default_context = 8192
allow_cpu_fallback = true
engine = "llama_cpp"

[storage]
models_dir = "~/Library/Application Support/mangosteen/models"
default_source = "modelscope"
```

### 云端配置（启用优云智算）

```toml
config_version = 1

[providers.compshare]
driver = "compshare"
enabled = true
display_name = "优云智算"

[providers.compshare.secret]
env = "COMPSHARE_PRIVATE_KEY"

[providers.compshare.options]
public_key = "your-public-key"
region = "cn-wlcb"
zone = "cn-wlcb-01"
image_id = "compshareImage-xxxx"
charge_type = "Postpay"
```

**注意**：修改配置后，重启 mangosteen 网关使配置生效。

## 常见问题快速排查

### 问题 1：部署失败 - 无可用云端算力节点

**错误信息**：
```
✗ 无可用云端算力节点：本地部署不可行；但既没有已保存的设备，也没有可用的云服务商。
```

**原因**：配置文件中强制使用 SSH，但没有配置设备

**快速解决**：
1. 检查配置：`mangosteen config show`
2. 简化配置：移除 `model_whitelist` 和 `remote_devices`
3. 重新部署：`mangosteen deploy <模型>`

### 问题 2：引擎动态库找不到

**错误信息**：
```
[FAIL] 本地推理引擎
       /usr/local/bin/llama-server 存在但无法运行：Library not loaded
```

**原因**：llama-server 的动态库路径未注入

**快速解决**：
1. 查看注入路径：`mangosteen engine env`
2. 检查引擎位置：`mangosteen engine locate`
3. 手动指定（如果需要）：在配置中设置 `local.engine_path`

### 问题 3：端口被占用

**错误信息**：
```
[WARN] 网关端口
         11516 已被占用
```

**快速解决**：
```bash
mangosteen stop --all
```

### 问题 4：云端实例忘了关

**风险**：持续计费

**快速解决**：
```bash
mangosteen cloud instances
mangosteen stop <部署ID>
```

### 问题 5：模型下载失败

**原因**：网络问题或源服务器不可用

**快速解决**：
1. 切换源：`mangosteen models pull hf:<模型>`
2. 检查网络连接
3. 使用代理（如需要）

## 关键概念

### 本地优先策略

调度决策器严格按此顺序：
```
本地资源满足 → 本地部署（永远优先）
本地资源不足 → 云端降级（只在必要时）
本地部署失败 → 云端降级 + 记录原因
```

### 资源评估公式

```
总需求 = 权重 + KV Cache + 计算缓冲 + 运行时开销
```

- **权重**：参数量 × 量化位宽
- **KV Cache**：层数 × KV头数 × head_dim × 上下文 × KV精度
- **计算缓冲**：批大小 × 隐藏维度
- **运行时开销**：CUDA context / Metal / 线程栈

**为什么单独算 KV Cache**：消费级显卡上真正卡人的往往是它。GQA 模型（如 Qwen2.5）在 32K 上下文只需 ~1.7 GiB，而不带 GQA 的老模型 8K 就要 4 GiB。

### 云端四维打分

```
总分 = w_price·价格分 + w_latency·延迟分 + w_availability·可用性分 + w_hardware·硬件分
```

- 价格：最低价为 1，其它按反比
- 延迟：最低延迟为 1；未探测到给 0.5
- 可用性：库存富余度 × 0.6 + 支持按量释放 × 0.2 + 有报价 × 0.2
- 硬件：GPU 型号偏好 × 0.5 + 显存富余度 × 0.5

硬性约束：最低显存、最低内存、价格上限、服务商白名单、地域白名单、库存要求。

## OpenAI 兼容接口

部署完成后，可以使用标准 OpenAI SDK：

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:11516/v1",
    api_key="not-needed"  # Mangosteen 不鉴权
)

resp = client.chat.completions.create(
    model="auto",  # "auto" = 用当前部署的模型
    messages=[{"role": "user", "content": "你好"}],
)
print(resp.choices[0].message.content)
```

## 配置说明

配置文件位置：
- macOS: `~/Library/Application Support/mangosteen/config.toml`
- Linux: `~/.config/mangosteen/config.toml`
- Windows: `%APPDATA%\mangosteen\config.toml`

关键配置项：

```toml
[gateway]
port = 11516                # 默认端口

[scheduler]
local_first = true          # 本地优先（不要关掉）
max_price_per_hour = 5.0    # 云端价格上限

[local]
default_context = 8192
allow_cpu_fallback = true   # 允许 CPU 降级
allow_partial_offload = true # 允许部分卸载
```

查看配置：
```bash
mangosteen config show
mangosteen config path
```

## 跨平台兼容性

Mangosteen 完全支持 macOS/Windows/Linux，三个平台都提供：
- macOS (Intel): `mangosteen-macos-x86_64.tar.gz`
- macOS (Apple Silicon): `mangosteen-macos-aarch64.tar.gz`
- Linux (x86_64): `mangosteen-linux-x86_64.tar.gz`
- Linux (aarch64): `mangosteen-linux-aarch64.tar.gz`
- Windows (x86_64): `mangosteen-windows-x86_64.zip`

**推理引擎集成**：
- 集成方式与 Ollama 一致：引擎和动态库作为一个整体
- 库搜索路径由 Mangosteen 自动注入（不依赖系统包管理器）
- 查找顺序：`local.engine_path` → 同级 `runtime/<平台-架构>/` → `PATH`

## 安全与成本提醒

⚠️ **云端计费警告**：
- 云端实例按小时计费，用完必须销毁
- 台账会记录所有实例，建议定期检查 `mangosteen cloud instances`
- 压测规则：同一时刻只允许 1 台 GPU 实例运行，严禁并发创建

⚠️ **凭证安全**：
- 云服务商凭证支持三种写法：
  ```toml
  secret = { env = "MY_TOKEN" }         # 从环境变量读（推荐）
  secret = { file = "/run/secrets/tok" } # 从文件读
  secret = { inline = "xxx" }            # 直接内联（仅调试用）
  ```
- `config show` 不会明文输出凭证

## Web UI（可选）

如果用户需要图形界面：

```bash
mangosteen ui          # 启动控制台并自动打开浏览器
mangosteen ui --no-open  # 只起服务（SSH / 无桌面环境）
```

界面功能：
- **对话**：流式对话，支持文档附件
- **部署**：搜索模型 → 下载 → 部署 → 停止/删除
- **设备**：CPU/内存实时曲线、加速卡、磁盘剩余
- **设置**：调度策略、本地推理参数、云服务商开关

## 参考文档

详细参考文档请查看：
- @references/commands.md - 命令速查表
- @references/resource-estimation.md - 资源评估公式详解
- @references/cloud-providers.md - 云服务商配置指南
- @references/troubleshooting.md - 故障排查手册
- @references/faq.md - 常见问题 FAQ（37+ 问题）
- QUICKSTART.md - 5 分钟快速开始指南
- CHANGELOG.md - 版本历史
- TEST_REPORT.md - 本地自测报告（43/43 测试通过）
