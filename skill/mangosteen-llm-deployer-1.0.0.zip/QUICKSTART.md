# Mangosteen 大模型部署助手 - 快速开始

## 5 分钟快速开始

### 步骤 1：安装 Mangosteen（2 分钟）

#### macOS/Linux

```bash
# 从 Release 下载
curl -L https://github.com/zhuzhichaoTM/mangosteen/releases/download/v0.1.0/mangosteen-macos-x86_64.tar.gz -o mangosteen.tar.gz
tar -xzf mangosteen.tar.gz
sudo mv mangosteen /usr/local/bin/
```

#### Windows

下载 `mangosteen-windows-x86_64.zip`，解压后添加到 PATH。

#### 验证安装

```bash
mangosteen --version
```

### 步骤 2：环境准备（1 分钟）

```bash
# 运行环境准备脚本
bash ~/.workbuddy/skills/mangosteen-llm-deployer/scripts/prepare-env.sh
```

该脚本会：
- 检查 mangosteen 是否安装
- 运行环境自检
- 检查配置文件
- 检查本地模型

### 步骤 3：下载模型（1 分钟）

```bash
# 下载 qwen2.5-0.5b 模型（推荐新手）
mangosteen models pull Qwen/Qwen2.5-0.5B-Instruct-GGUF/qwen2.5-0.5b-instruct-q4_k_m.gguf
```

### 步骤 4：部署模型（1 分钟）

```bash
# 使用快速部署脚本
bash ~/.workbuddy/skills/mangosteen-llm-deployer/scripts/quick-deploy.sh qwen2.5-0.5b-instruct 8192
```

或手动部署：

```bash
# 评估资源
mangosteen assess qwen2.5-0.5b-instruct --context 8192

# 部署
mangosteen deploy qwen2.5-0.5b-instruct --context 8192
```

### 步骤 5：使用模型（即时可用）

#### Python SDK

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:11516/v1",
    api_key="not-needed"
)

resp = client.chat.completions.create(
    model="auto",
    messages=[{"role": "user", "content": "你好"}],
)
print(resp.choices[0].message.content)
```

#### cURL

```bash
curl http://127.0.0.1:11516/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "auto",
    "messages": [{"role": "user", "content": "你好"}]
  }'
```

## 场景指南

### 场景 A：纯本地 CPU 推理（最简单）

**适用**：测试、小规模使用

**配置**：使用默认配置即可

**命令**：
```bash
mangosteen deploy qwen2.5-0.5b-instruct --context 8192
```

**注意**：CPU 推理速度较慢（<5 tok/s）

### 场景 B：云端 GPU 推理（推荐）

**适用**：需要高性能

**配置**：
1. 启用云服务商（如优云智算）
2. 充值账户
3. 配置凭证

**命令**：
```bash
mangosteen deploy qwen2.5-7b-instruct --context 8192
```

**注意**：按小时计费，用完必须停止

### 场景 C：混合部署（灵活）

**适用**：小模型本地，大模型云端

**配置**：保持 `local_first = true`

**命令**：
```bash
# 小模型本地跑
mangosteen deploy qwen2.5-0.5b-instruct --context 8192

# 大模型自动上云
mangosteen deploy llama3.3-70b --context 8192
```

## 常用命令速查

```bash
# 查看状态
mangosteen status

# 停止所有部署
mangosteen stop --all

# 查看本地模型
mangosteen models list

# 环境自检
mangosteen doctor

# 查看配置
mangosteen config show
```

## 故障排查

### 问题 1：部署失败

**解决**：
```bash
mangosteen doctor
mangosteen config show
```

### 问题 2：端口被占用

**解决**：
```bash
mangosteen stop --all
```

### 问题 3：云端实例忘了关

**解决**：
```bash
mangosteen cloud instances
mangosteen stop <部署ID>
```

## 下一步

- 详细文档：查看 `references/` 目录
- 命令速查：`references/commands.md`
- 故障排查：`references/troubleshooting.md`
- 常见问题：`references/faq.md`
- 配置指南：`references/cloud-providers.md`

## 获取帮助

- GitHub: https://github.com/zhuzhichaoTM/mangosteen
- Issues: https://github.com/zhuzhichaoTM/mangosteen/issues
